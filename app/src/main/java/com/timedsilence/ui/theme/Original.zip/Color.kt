package com.timedsilence.ui.theme

import androidx.compose.ui.graphics.Color

val BahamaBlue = Color(red = 0, green = 102, blue = 140)
val Geyser = Color(214, 219, 225)
val PrimaryContainer = Color(178, 207, 221)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)